/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hypermart;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author kanishk-pc
 */
public class productsList {
    private ArrayList<product> productsList;

   
    private int count = 0;
    
    public productsList(){
         productsList = new ArrayList<>();
    }
    
     public product getProduct(int index) {
        product p1  = new product();
        int length = this.CountLines()/11;
        for(int i = 0 ; i < length; i++){
         p1 = productsList.get(i);
        }
        return p1;
    }
    
    public int CountLines() {
       
            BufferedReader bufReader;
        try {
            bufReader = new BufferedReader(new FileReader("productDetails.txt"));
        
            String line = bufReader.readLine(); 
            int count =0;
             while (line != null) { 
                line = bufReader.readLine();
                count++; 
             }
            bufReader.close();           
        return count;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(productsList.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(productsList.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }
    
    public boolean loadFromFile(){
        boolean isLoaded = false;
        File file = new File("productDetails.txt");
        try {
            int length = this.CountLines()/12;
            BufferedReader bin = new BufferedReader(new FileReader(file));
            for(int i = 0; i< length; i++){
                product auxi = new product();
                auxi.loadFromFile(bin);
               this.productsList.add(auxi);
               
               
            }
            isLoaded = true;
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        return isLoaded;
    }
    
    // Load from file function to get an updated List
     public productsList loadFromFileGetList(){
         productsList updatedList = new productsList();
        
        File file = new File("productDetails.txt");
        try {
            int length = this.CountLines()/12;
            BufferedReader bin = new BufferedReader(new FileReader(file));
            for(int i = 0; i< length; i++){
                product auxi = new product();
                auxi.loadFromFile(bin);
               updatedList.addProduct(auxi);
               
               
            }
            
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
        return updatedList;
    }
     
     public void sortById(){
         Collections.sort(productsList,Comparator.comparing(product::getID));
     }
    
    public boolean saveToFile(String id, String name, String weight, String price, String VAT, String manuName,String Expiry, String lastOrderDate, String reorderQty, String picture, String availableQty, boolean append){
        boolean isSaved = false;
        try {
            
        File file = new File("productDetails.txt");
        
            BufferedWriter bin = new BufferedWriter(new FileWriter(file, append));
               bin.write("¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬"+"\n");
               bin.write(id+"\n");
               bin.write(name+"\n");
               bin.write(weight+"\n");
               bin.write(price+"\n");
               bin.write(VAT+"\n");
               bin.write(manuName+"\n");
               bin.write(Expiry+"\n");
               bin.write(lastOrderDate+"\n");
               bin.write(reorderQty+"\n");
               bin.write(picture+"\n");
               bin.write(availableQty+"\n");
               bin.close();
               isSaved = true;
               
              
          return isSaved;  
        } catch (FileNotFoundException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(productsList.class.getName()).log(Level.SEVERE, null, ex);
        } 
        return isSaved;  
    }
    
    
    // TO Save the entire updated product List Inside the file.
      public boolean saveToFile() {
          boolean isSaved = false;
        try {
            
            
            FileWriter theWriter;
            
            theWriter = new FileWriter("productDetails.txt",false);
            BufferedWriter bin = new BufferedWriter(theWriter);
            for(int i = 0; i<productsList.size();i++){
                bin.write("¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬"+"\n");
                productsList.get(i).saveToFile(bin);
                
            }
            isSaved = true;
            

            bin.close();
            bin = null;
           
            return isSaved;
        } catch (IOException ex) {
            Logger.getLogger(productsList.class.getName()).log(Level.SEVERE, null, ex);
        }
        return isSaved;
    }
    
    
    
    public boolean updateFile(String id, String name, String weight, String price, String VAT, String manuName, String Expiry, String lastOrderDate, String reorderQty, String picture, String availableQty){
        boolean isSaved = false;
        product p1 = new product(Integer.parseInt(id), name, Double.parseDouble(weight), Double.parseDouble(price),Double.parseDouble(VAT), manuName,LocalDate.parse(Expiry),LocalDate.parse(lastOrderDate), Integer.parseInt(reorderQty),picture, Integer.parseInt(availableQty));
        productsList.add(p1);
        isSaved = true;
        return isSaved;
    }
    
    
    
    public void startDisplay(){  
            productsList.get(count).setFrame();           
            
    }
    
    public int getSize(){
        
        return productsList.size();
    }
    
    public void nextDisplay(JButton btn){ 
        int length = (this.CountLines()/12);
        if(count == length-1){
            JOptionPane.showMessageDialog(null,"Upper Limit Reached");
            count = 0;
            productsList.get(count).setFrame();
        }
        else{
            productsList.get(count).dispose();
            count++;
            product obj = productsList.get(count);           
            obj.setFrame();
        }
            
    }
    
    public void prevDisplay(){
        if(count == 0){
            productsList.get(count).dispose();
           JOptionPane.showMessageDialog(null,"Lower Limit Reached");
           count = (this.CountLines()/12) - 1;
           productsList.get(count).setFrame();
        }else{
        productsList.get(count).dispose();
        count--;
        productsList.get(count).setFrame();
        }
        
    }
    
    
    // Implementing Search Functionality
    
    public boolean searchByID(String ID){
        for(int i = 0; i< productsList.size() ; i++){
            int theId = productsList.get(i).getID();
            if( theId == Integer.parseInt(ID)){
                productsList.get(i).setFrame();
                return true;
            }
            
        }
       
        String message = String.format("There is no product with the ID %s", ID);
        JOptionPane.showMessageDialog(null, message);
        
        return false;
            
    }
    
    public product searchByIDgetProduct(String ID){
        product updated = new product();

        
        for(int i = 0; i< productsList.size() ; i++){
            int theId = productsList.get(i).getID();
            if( theId == Integer.parseInt(ID)){
                updated =  productsList.get(i);
            }   
        }

       
        
        
        return updated;
            
    }
    
    public void addProduct(product p1){
        productsList.add(p1);
    }
    
    
    public boolean deleteProduct(product p1){
        boolean deleted = false;
        productsList.remove(p1);
        deleted = true;
        return deleted;
        
    }
    
    
    
    public boolean searchByAnything(String categoryType, String AssociatedValue, FilteredTable T1){
        boolean isFound = false;
        
        switch( categoryType ){
            
            case "weight":
                
                for(int i = 0; i< productsList.size(); i++){
                String delimitor = "-";
                String weightRanges [] = AssociatedValue.split(delimitor);
                
                double weight = productsList.get(i).getWeight();
                double lowerLim = Double.parseDouble(weightRanges[0]);
                double UpperLim = Double.parseDouble(weightRanges[1]);
                 DecimalFormat df = new DecimalFormat("0.00");   
                    if( weight > lowerLim && weight < UpperLim){
                        
                        double Vat = productsList.get(i).getVAT();
                        double price = productsList.get(i).getPrice();
                        double VatAmount = (Vat/100) * price;
                        String VatInc = df.format(price + VatAmount);
                        String picture = productsList.get(i).getPicture();
                        String ID = String.valueOf(productsList.get(i).getID());
                       
                        
                        
                        Object data[] =  {String.valueOf(productsList.get(i).getID()),
                                          productsList.get(i).getName(), 
                                          String.valueOf(productsList.get(i).getWeight()),
                                          String.valueOf(price),
                                          String.valueOf(Vat),
                                          VatInc,
                                          String.valueOf(productsList.get(i).getExpiryDate()),
                                          String.valueOf(productsList.get(i).getLastOrderDate()), 
                                          String.valueOf(productsList.get(i).getReorderQuantity()), 
                                          picture,
                                          String.valueOf(productsList.get(i).getAvailableQuantity())
                                           };
                                          
                        
                        T1.addRow(data);
                        T1.ImageRender(9, picture);
                        isFound= true;   
                    }
                }
                break;
                
            
            case "price":
                
                 for(int i = 0; i< productsList.size(); i++){
                String delimitor = "-";
                String priceRanges [] = AssociatedValue.split(delimitor);
                
                double price = productsList.get(i).getPrice();
                double lowerLim = Double.parseDouble(priceRanges[0]);
                double UpperLim = Double.parseDouble(priceRanges[1]);
                 DecimalFormat df = new DecimalFormat("0.00");   
                    if( price > lowerLim && price < UpperLim){
                        
                        double Vat = productsList.get(i).getVAT();
                        double VatAmount = (Vat/100) * price;
                        String VatInc = df.format(price + VatAmount);
                        String picture = productsList.get(i).getPicture();
                        String ID = String.valueOf(productsList.get(i).getID());
                       
                        
                        
                        Object data[] =  {String.valueOf(productsList.get(i).getID()),
                                          productsList.get(i).getName(), 
                                          String.valueOf(productsList.get(i).getWeight()),
                                          String.valueOf(price),
                                          String.valueOf(Vat),
                                          VatInc,
                                          String.valueOf(productsList.get(i).getExpiryDate()),
                                          String.valueOf(productsList.get(i).getLastOrderDate()), 
                                          String.valueOf(productsList.get(i).getReorderQuantity()), 
                                          picture,
                                          String.valueOf(productsList.get(i).getAvailableQuantity())
                                           };
                                          
                        
                        T1.addRow(data);
                        T1.ImageRender(9, picture);
                        isFound= true;   
                    }
                }
                break;
                
                
                
                
                
            case "":
                JOptionPane.showMessageDialog(null, "You need Enter appropriate values to continue");
                break;
                
                
            default:
                JOptionPane.showMessageDialog(null, "Not Found");
                break;
                     
        }
      
        return isFound;
        
    }
    
    
    public String getTotalStockValue(){
        double answer = 0;
        double StockValueforone = 0;
        for(int i = 0; i< productsList.size();i++){
             StockValueforone = productsList.get(i).getPrice() * productsList.get(i).getAvailableQuantity();
            answer = answer + StockValueforone;
        }
        return String.valueOf(answer);  
    }
    
    public String getAvailableProducts(){
        return String.valueOf(productsList.size());
    }
    
    public String getExpiredItems(){
        double answer = 0;
        boolean isExpiredforOne = false;
        int val = 0;
        int count = 0;
        for(int i = 0; i< productsList.size();i++){
            val = productsList.get(i).getExpiryDate().compareTo(LocalDate.now());
             if(val < 0){
                 isExpiredforOne = true;
                 count += 1;
             }
        }
        return String.valueOf(count);  
        
    }
    
    public String getNearExpiryItems(){
        double answer = 0;
        boolean isAboutToExpireforOne = false;
        int val = 0;
        int count = 0;
        for(int i = 0; i< productsList.size();i++){
             long days  = ChronoUnit.DAYS.between(LocalDate.now(),productsList.get(i).getExpiryDate() );
            System.out.print(days + "\n");
             if(days < 15 && days >= 0){ // For effective reuse and allocating time to the owner 14 days as chosen
                 isAboutToExpireforOne = true;
                 count += 1;
             }
        }
        
        return String.valueOf(count);  
        
    }
    
    public String getTotalStockQuantity(){
        double answer = 0;
        double StockQuantityforone = 0;
        for(int i = 0; i< productsList.size();i++){
             StockQuantityforone = productsList.get(i).getAvailableQuantity();
            answer = answer + StockQuantityforone;
        }
        return String.valueOf(answer); 
        
    }
    
    public String getproductThatNeedReorder(){
        double count = 0;
        boolean flag = false;
        for(int i = 0; i< productsList.size();i++){
             if(productsList.get(i).getAvailableQuantity() <= productsList.get(i).getReorderQuantity()){;
            count += 1;
        } 
    }
        return String.valueOf(count); 
    }
    
    
    
    
    
}
