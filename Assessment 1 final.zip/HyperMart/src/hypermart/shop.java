/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hypermart;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author kanishk-pc
 */
public class shop {
    private double cashSales;
    private double nonCashSales;
    private String Owner;
    private String Location;
    
    public shop(){
        cashSales = -1;
        nonCashSales = -1;
        Owner = "dummy";
        Location = "dummy";
        
    }
    
    public void edit(double cashsales ,double nonCashSales, String Owner, String Location){
        this.cashSales = cashsales;
        this.nonCashSales = nonCashSales;
        this.Owner = Owner;
        this.Location = Location;
    }

    public double getCashSales() {
        return cashSales;
    }

    public double getNonCashSales() {
        return nonCashSales;
    }

    public String getOwner() {
        return Owner;
    }

    public String getLocation() {
        return Location;
    }
    
    public void loadDetailsFromFile() throws FileNotFoundException, IOException{
        FileReader f1 = new FileReader("shopDetails.txt");
        BufferedReader bin = new BufferedReader(f1);
        String delimitor = bin.readLine();
        Double cashSales = Double.parseDouble(bin.readLine());
        Double nonCashSales = Double.parseDouble(bin.readLine());
        String Location = bin.readLine();
        String Ownwer = bin.readLine();
        
        this.edit(cashSales, nonCashSales, Ownwer, Location);
  
    }
    
    
}
