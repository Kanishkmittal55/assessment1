/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hypermart;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author kanishk-pc
 */
public class MainJFrame extends javax.swing.JFrame implements Runnable {
    
    private User theUser = new User(); // For logging into the System
    private int hour, second, minute; // To display a constant time
    
    private productsList productsList;
    
    private final JFileChooser openFileChooser;
    
    private shop ourShop= new shop();
    private java.awt.Component jTabInMemoryWelcome;
    private java.awt.Component jTabInMemoryProductDetails;
    private java.awt.Component jTabInMemoryReorder;
    private java.awt.Component jTabInMemoryBuyGoods;
    private java.awt.Component jTabInMemoryEditDetails;
    private java.awt.Component jTabInMemoryDeleteProducts;
    
    
    
    
    
     public void currentdateTime(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime now = LocalDateTime.now();
        jCurrentDateLabel.setText(dtf.format(now));
        jCurrentDateLabel1.setText(dtf.format(now));
        jCurrentDateLabel.setText(dtf.format(now));
        jCurrentDateLabel1.setText(dtf.format(now));
    }

    // Start of the Constructor
    
    public MainJFrame() {
        initComponents();
        
        this.currentdateTime();
        Thread t = new Thread(this);
        t.start();
        productsList = new productsList();
        productsList.loadFromFile();
        
        
        openFileChooser = new JFileChooser("");
        openFileChooser.addChoosableFileFilter(new FileNameExtensionFilter("PNG", "png"));
        openFileChooser.addChoosableFileFilter(new FileNameExtensionFilter("JPG","jpg"));
        openFileChooser.addChoosableFileFilter(new FileNameExtensionFilter("SVG", "svg" ));
        
        int Login = getIndexByName("Login");
        int welcome = getIndexByName( "Welcome");
        int details = getIndexByName("Product Details"); 
        int Reorder = getIndexByName("Reorder");
        int buy = getIndexByName("Buy Goods");
        int edit = getIndexByName("Edit Details");
        int delete = getIndexByName("Delete Products");
        
        jTabInMemoryWelcome = jMainTabbedPane.getComponentAt(welcome);
        jTabInMemoryProductDetails = jMainTabbedPane.getComponentAt(details);
        jTabInMemoryReorder = jMainTabbedPane.getComponentAt(Reorder);
        jTabInMemoryBuyGoods = jMainTabbedPane.getComponentAt(buy);
        jTabInMemoryEditDetails = jMainTabbedPane.getComponentAt(edit);
        jTabInMemoryDeleteProducts = jMainTabbedPane.getComponentAt(delete);
        
        removeTabsByName("Welcome");
        removeTabsByName("Product Details");
        removeTabsByName("Reorder");
        removeTabsByName("Buy Goods");
        removeTabsByName("Edit Details");
        removeTabsByName("Delete Products");
        
        
        // Setting up the Welcome Page (Stock Details Panel)
        jStockValueOutput.setText(productsList.getTotalStockValue());
        jAvailableProductsOutput.setText(productsList.getAvailableProducts());
        jExpiredItemsOutput.setText(productsList.getExpiredItems());
        jNearExpiryOutput.setText(productsList.getNearExpiryItems());
        jTotalStockQuantity.setText(productsList.getTotalStockQuantity());
        jPNMQOutput1.setText(productsList.getproductThatNeedReorder());
        jTAPOutput1.setText(productsList.getAvailableProducts());
        
        // User Details Panel
        // Setup in the jLoginButtonPressed method
        
        
        // The Shop details panel
        try {
            ourShop.loadDetailsFromFile();
        } catch (IOException ex) {
            Logger.getLogger(MainJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        jTotalCashSaleOutput.setText(String.valueOf(ourShop.getCashSales()));
        jTotalNonCashSaleOutput.setText(String.valueOf(ourShop.getNonCashSales()));
        jLocationNameOutput.setText(ourShop.getLocation());
        jOwnerNameOutput.setText(ourShop.getOwner());
        
        
        // Delete Products Tab
        jDelButton1.setEnabled(false);
        
        
        // Add new Products Tabs
        int lastId = productsList.getSize();
        jProductIdNewProduct.setText(String.valueOf(lastId + 1));
        jProductIdNewProduct.setEnabled(false);
        
        //Reorder New products
        jReOrder.setEnabled(false);
        
        // Buy New Goods Tab
        jPurchaseBG.setEnabled(false);
        
        
    }
    
    // End of Constructor 
    
    
    
    // Overiding the run method of the thread Class to display a live clock and date in my software.
    @Override
    public void run(){
        while(true){
            Calendar cal = Calendar.getInstance();
            
            hour = cal.get(Calendar.HOUR_OF_DAY);
            minute =  cal.get(Calendar.MINUTE);
            second = cal.get(Calendar.SECOND);
            
            SimpleDateFormat sd24 = new SimpleDateFormat("HH:mm:ss");
            Date date = cal.getTime();
            String time24 = sd24.format(date);
            jCurrentTimeLabel.setText(time24);
            jCurrentTimeLabel1.setText(time24);
          
        }
    }
    
    
    // Helper method to get the index of the tabs in a dynamic manner.
    
   public int getIndexByName(String title){
       int length = jMainTabbedPane.getTabCount();
       for(int i =0 ; i< jMainTabbedPane.getTabCount(); i++){
           if(jMainTabbedPane.getTitleAt(i).equals(title)){
               return i;
           }
       }
       return -1;
   }
   
   private void removeTabsByName(String title){
      
        for(int index = 0;index <jMainTabbedPane.getTabCount() ;index++){
           
             if(jMainTabbedPane.getTitleAt(index).contentEquals(title)){
                jMainTabbedPane.remove(index);
            }
        }
    }
 
    

    /**
     * This method is called from within the constructor to initialize the form. WARNING: Do NOT modify this code. The content of this method is always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        product1 = new hypermart.product();
        product2 = new hypermart.product();
        jMainTabbedPane = new javax.swing.JTabbedPane();
        jLoginPanel = new javax.swing.JPanel();
        jRegisterUserButton = new javax.swing.JButton();
        jCurrentDateLabel = new javax.swing.JLabel();
        jCurrentTimeLabel = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jMainLogoPosterLabel = new javax.swing.JLabel();
        jUserNameField = new javax.swing.JTextField();
        jPasswordField = new javax.swing.JPasswordField();
        jEnterUsernameLabel = new javax.swing.JLabel();
        jEnterPasswordLabel = new javax.swing.JLabel();
        jLoginButton = new javax.swing.JButton();
        jWelcomePanel = new javax.swing.JPanel();
        jProductsPanel = new javax.swing.JPanel();
        jStockDetails = new javax.swing.JPanel();
        jPriceLabel = new javax.swing.JLabel();
        jVATLabel = new javax.swing.JLabel();
        jTotalPriceLabel = new javax.swing.JLabel();
        jIDLabel = new javax.swing.JLabel();
        jWeightLabel = new javax.swing.JLabel();
        jStockValueOutput = new javax.swing.JLabel();
        jAvailableProductsOutput = new javax.swing.JLabel();
        jExpiredItemsOutput = new javax.swing.JLabel();
        jNearExpiryOutput = new javax.swing.JLabel();
        jTotalStockQuantity = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jProductsPanel1 = new javax.swing.JPanel();
        jStockDetails1 = new javax.swing.JPanel();
        jProductNearingMinQtyLabel = new javax.swing.JLabel();
        jTotalAvailableProductsLabel = new javax.swing.JLabel();
        jTotalCashSaleOutput = new javax.swing.JLabel();
        jTotalNonCashSaleOutput = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLocationNameOutput = new javax.swing.JLabel();
        jOwnerNameOutput = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jProductsPanel2 = new javax.swing.JPanel();
        jStockDetails2 = new javax.swing.JPanel();
        jProductNearingMinQtyLabel1 = new javax.swing.JLabel();
        jTotalAvailableProductsLabel1 = new javax.swing.JLabel();
        jTAPOutput1 = new javax.swing.JLabel();
        jPNMQOutput1 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jProductsPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jusername = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jemail = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jContactNo = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jDesignation = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jProductDetailsPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLoadFromFile = new javax.swing.JButton();
        jNextProductButton = new javax.swing.JButton();
        jPreviousProductButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jIDSearchField = new javax.swing.JTextField();
        jSearchByIdBtn = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jSearchCategoryField = new javax.swing.JTextField();
        jSearchByAnythingButton = new javax.swing.JButton();
        jAssociatedValueField = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jExpiry = new javax.swing.JTextField();
        jWeight = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLastOrderDate = new javax.swing.JTextField();
        jPrice = new javax.swing.JTextField();
        jMinReorderQuantity = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jPicture = new javax.swing.JTextField();
        jVAT = new javax.swing.JTextField();
        jAmountInStock = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jName = new javax.swing.JTextField();
        jSaveoFileButton = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jImageChooserButton = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jManufacturedBy = new javax.swing.JTextField();
        jProductId = new javax.swing.JLabel();
        jProductIdNewProduct = new javax.swing.JTextField();
        jEditDetails = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jExpiry1 = new javax.swing.JTextField();
        jWeight1 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLastOrderDate1 = new javax.swing.JTextField();
        jPrice1 = new javax.swing.JTextField();
        jMinReorderQuantity1 = new javax.swing.JTextField();
        jLabel32 = new javax.swing.JLabel();
        jPicture1 = new javax.swing.JTextField();
        jVAT1 = new javax.swing.JTextField();
        jAmountInStock1 = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jName1 = new javax.swing.JTextField();
        jSaveToFileButtonEditDetails = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jImageChooserButton1 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        jManufacturedBy1 = new javax.swing.JTextField();
        jProductId1 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jIDSearchField1 = new javax.swing.JTextField();
        jSearchByIdBtnReorderTab = new javax.swing.JButton();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jReorderPanel = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jIDSearchField2 = new javax.swing.JTextField();
        jSearchByIdReorder = new javax.swing.JButton();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jReOrder = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jPurchaseAmountLabel = new javax.swing.JLabel();
        jPurchaseQtyField = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        jUpdatedStockOutput = new javax.swing.JLabel();
        jStockLevelOutput = new javax.swing.JLabel();
        jProductNameOutput = new javax.swing.JLabel();
        jButtonReorder = new javax.swing.JButton();
        jSalesPanel = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jIDSearchField3 = new javax.swing.JTextField();
        jSearchByIdBuyGoods = new javax.swing.JButton();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jupdatedStock = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jPurchaseAmountLabel1 = new javax.swing.JLabel();
        jPurchaseQtyField1 = new javax.swing.JTextField();
        jStockLevelOutput1 = new javax.swing.JLabel();
        jProductNameOutput1 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jCurrentTimeLabel1 = new javax.swing.JLabel();
        jCurrentDateLabel1 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jButtonBuyGoods = new javax.swing.JButton();
        jTotalPriceOutput = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jPriceFor1Output = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jVatOutput = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jPriceWithVatOutput = new javax.swing.JLabel();
        jPurchaseBG = new javax.swing.JButton();
        jDeletePanel = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jIDSearchField4 = new javax.swing.JTextField();
        jSearchByIdBtnDeleteProducts = new javax.swing.JButton();
        jLabel50 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jStockLevelOutput2 = new javax.swing.JLabel();
        jProductNameOutput2 = new javax.swing.JLabel();
        jDelButton1 = new javax.swing.JButton();

        javax.swing.GroupLayout product1Layout = new javax.swing.GroupLayout(product1.getContentPane());
        product1.getContentPane().setLayout(product1Layout);
        product1Layout.setHorizontalGroup(
            product1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        product1Layout.setVerticalGroup(
            product1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout product2Layout = new javax.swing.GroupLayout(product2.getContentPane());
        product2.getContentPane().setLayout(product2Layout);
        product2Layout.setHorizontalGroup(
            product2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        product2Layout.setVerticalGroup(
            product2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 204));
        setForeground(new java.awt.Color(255, 255, 204));

        jLoginPanel.setBackground(new java.awt.Color(255, 255, 204));
        jLoginPanel.setForeground(new java.awt.Color(255, 255, 204));

        jRegisterUserButton.setBackground(new java.awt.Color(255, 255, 0));
        jRegisterUserButton.setText("Not a User ? Register Now ");
        jRegisterUserButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegisterUserButtonActionPerformed(evt);
            }
        });

        jCurrentDateLabel.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jCurrentDateLabel.setForeground(new java.awt.Color(0, 0, 255));
        jCurrentDateLabel.setText("Date");

        jCurrentTimeLabel.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jCurrentTimeLabel.setForeground(new java.awt.Color(51, 51, 255));
        jCurrentTimeLabel.setText("Time ");

        jMainLogoPosterLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hypermart/logo.png"))); // NOI18N
        jMainLogoPosterLabel.setText("jLabel1");

        jEnterUsernameLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jEnterUsernameLabel.setText("Enter Username : ");

        jEnterPasswordLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jEnterPasswordLabel.setText("Enter Password : ");

        jLoginButton.setBackground(new java.awt.Color(255, 255, 0));
        jLoginButton.setForeground(new java.awt.Color(0, 0, 204));
        jLoginButton.setText("Login");
        jLoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLoginButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jMainLogoPosterLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jEnterPasswordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jPasswordField))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jEnterUsernameLabel)
                        .addGap(32, 32, 32)
                        .addComponent(jUserNameField)))
                .addGap(35, 35, 35))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLoginButton)
                .addGap(99, 99, 99))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jMainLogoPosterLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jEnterUsernameLabel)
                    .addComponent(jUserNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPasswordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jEnterPasswordLabel))
                .addGap(18, 18, 18)
                .addComponent(jLoginButton)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jLoginPanelLayout = new javax.swing.GroupLayout(jLoginPanel);
        jLoginPanel.setLayout(jLoginPanelLayout);
        jLoginPanelLayout.setHorizontalGroup(
            jLoginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLoginPanelLayout.createSequentialGroup()
                .addGroup(jLoginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jLoginPanelLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jCurrentDateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCurrentTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jLoginPanelLayout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jLoginPanelLayout.createSequentialGroup()
                        .addGap(277, 277, 277)
                        .addComponent(jRegisterUserButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(191, Short.MAX_VALUE))
        );
        jLoginPanelLayout.setVerticalGroup(
            jLoginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLoginPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jLoginPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCurrentDateLabel)
                    .addComponent(jCurrentTimeLabel))
                .addGap(89, 89, 89)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 180, Short.MAX_VALUE)
                .addComponent(jRegisterUserButton)
                .addGap(35, 35, 35))
        );

        jMainTabbedPane.addTab("Login", jLoginPanel);

        jWelcomePanel.setBackground(new java.awt.Color(255, 255, 255));
        jWelcomePanel.setForeground(new java.awt.Color(255, 255, 255));

        jProductsPanel.setBackground(new java.awt.Color(255, 255, 153));
        jProductsPanel.setForeground(new java.awt.Color(255, 255, 153));

        jStockDetails.setBackground(new java.awt.Color(255, 255, 255));
        jStockDetails.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPriceLabel.setText("Total Stock Quantity :");

        jVATLabel.setText("Near Expiry Items :");

        jTotalPriceLabel.setText("Expired Items :");

        jIDLabel.setText("Available Products :");

        jWeightLabel.setText("Total Stock Value :");

        jStockValueOutput.setText("X");

        jAvailableProductsOutput.setText("xx");

        jExpiredItemsOutput.setText("XXX");

        jNearExpiryOutput.setText("xxxx");

        jTotalStockQuantity.setText("XXXX");

        javax.swing.GroupLayout jStockDetailsLayout = new javax.swing.GroupLayout(jStockDetails);
        jStockDetails.setLayout(jStockDetailsLayout);
        jStockDetailsLayout.setHorizontalGroup(
            jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jStockDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jStockDetailsLayout.createSequentialGroup()
                        .addComponent(jVATLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jNearExpiryOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jStockDetailsLayout.createSequentialGroup()
                        .addComponent(jIDLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jAvailableProductsOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jStockDetailsLayout.createSequentialGroup()
                        .addComponent(jWeightLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jStockValueOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jStockDetailsLayout.createSequentialGroup()
                            .addComponent(jTotalPriceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                            .addComponent(jExpiredItemsOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jStockDetailsLayout.createSequentialGroup()
                            .addComponent(jPriceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTotalStockQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 0, Short.MAX_VALUE))))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jStockDetailsLayout.setVerticalGroup(
            jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jStockDetailsLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jWeightLabel)
                    .addComponent(jStockValueOutput))
                .addGap(18, 18, 18)
                .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jIDLabel)
                    .addComponent(jAvailableProductsOutput))
                .addGap(18, 18, 18)
                .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTotalPriceLabel)
                    .addComponent(jExpiredItemsOutput))
                .addGap(18, 18, 18)
                .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jVATLabel)
                    .addComponent(jNearExpiryOutput))
                .addGap(18, 18, 18)
                .addGroup(jStockDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPriceLabel)
                    .addComponent(jTotalStockQuantity))
                .addGap(17, 17, 17))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel3.setText("---Stock Details---");

        javax.swing.GroupLayout jProductsPanelLayout = new javax.swing.GroupLayout(jProductsPanel);
        jProductsPanel.setLayout(jProductsPanelLayout);
        jProductsPanelLayout.setHorizontalGroup(
            jProductsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jProductsPanelLayout.createSequentialGroup()
                .addGroup(jProductsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jProductsPanelLayout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jLabel3))
                    .addGroup(jProductsPanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jStockDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        jProductsPanelLayout.setVerticalGroup(
            jProductsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jProductsPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel3)
                .addGap(31, 31, 31)
                .addComponent(jStockDetails, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        jProductsPanel1.setBackground(new java.awt.Color(255, 255, 153));
        jProductsPanel1.setForeground(new java.awt.Color(255, 255, 153));

        jStockDetails1.setBackground(new java.awt.Color(255, 255, 255));
        jStockDetails1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jProductNearingMinQtyLabel.setText("Non - Cash Sales :");

        jTotalAvailableProductsLabel.setText("Cash Sales :");

        jTotalCashSaleOutput.setText("X");

        jTotalNonCashSaleOutput.setText("xx");

        jLabel26.setText("Location : ");

        jLabel28.setText("Owner Name :");

        jLocationNameOutput.setText("Location");

        jOwnerNameOutput.setText("OwnerName");

        javax.swing.GroupLayout jStockDetails1Layout = new javax.swing.GroupLayout(jStockDetails1);
        jStockDetails1.setLayout(jStockDetails1Layout);
        jStockDetails1Layout.setHorizontalGroup(
            jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jStockDetails1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jProductNearingMinQtyLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                    .addComponent(jTotalAvailableProductsLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLocationNameOutput, javax.swing.GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE)
                    .addComponent(jOwnerNameOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTotalNonCashSaleOutput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTotalCashSaleOutput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jStockDetails1Layout.setVerticalGroup(
            jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jStockDetails1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTotalAvailableProductsLabel)
                    .addComponent(jTotalCashSaleOutput))
                .addGap(18, 18, 18)
                .addGroup(jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jProductNearingMinQtyLabel)
                    .addComponent(jTotalNonCashSaleOutput))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel26)
                    .addComponent(jLocationNameOutput))
                .addGap(18, 18, 18)
                .addGroup(jStockDetails1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jOwnerNameOutput)
                    .addComponent(jLabel28))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel4.setText("---Shop Details--- ");

        javax.swing.GroupLayout jProductsPanel1Layout = new javax.swing.GroupLayout(jProductsPanel1);
        jProductsPanel1.setLayout(jProductsPanel1Layout);
        jProductsPanel1Layout.setHorizontalGroup(
            jProductsPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jProductsPanel1Layout.createSequentialGroup()
                .addGroup(jProductsPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jProductsPanel1Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(jLabel4))
                    .addGroup(jProductsPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jStockDetails1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jProductsPanel1Layout.setVerticalGroup(
            jProductsPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jProductsPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jStockDetails1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(57, 57, 57))
        );

        jProductsPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jProductsPanel2.setForeground(new java.awt.Color(255, 255, 153));

        jStockDetails2.setBackground(new java.awt.Color(255, 255, 255));
        jStockDetails2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jProductNearingMinQtyLabel1.setText("Products Nearing Minimum Quantity :");

        jTotalAvailableProductsLabel1.setText("Total Available Products :");

        jTAPOutput1.setText("X");

        jPNMQOutput1.setText("xx");

        javax.swing.GroupLayout jStockDetails2Layout = new javax.swing.GroupLayout(jStockDetails2);
        jStockDetails2.setLayout(jStockDetails2Layout);
        jStockDetails2Layout.setHorizontalGroup(
            jStockDetails2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jStockDetails2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jStockDetails2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jStockDetails2Layout.createSequentialGroup()
                        .addComponent(jTotalAvailableProductsLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTAPOutput1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jStockDetails2Layout.createSequentialGroup()
                        .addComponent(jProductNearingMinQtyLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPNMQOutput1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jStockDetails2Layout.setVerticalGroup(
            jStockDetails2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jStockDetails2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jStockDetails2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTotalAvailableProductsLabel1)
                    .addComponent(jTAPOutput1))
                .addGap(18, 18, 18)
                .addGroup(jStockDetails2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jProductNearingMinQtyLabel1)
                    .addComponent(jPNMQOutput1))
                .addGap(103, 103, 103))
        );

        jLabel23.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel23.setText("---Reorder--- ");

        javax.swing.GroupLayout jProductsPanel2Layout = new javax.swing.GroupLayout(jProductsPanel2);
        jProductsPanel2.setLayout(jProductsPanel2Layout);
        jProductsPanel2Layout.setHorizontalGroup(
            jProductsPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jProductsPanel2Layout.createSequentialGroup()
                .addGroup(jProductsPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jProductsPanel2Layout.createSequentialGroup()
                        .addGap(96, 96, 96)
                        .addComponent(jLabel23))
                    .addGroup(jProductsPanel2Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jStockDetails2, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jProductsPanel2Layout.setVerticalGroup(
            jProductsPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jProductsPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel23)
                .addGap(55, 55, 55)
                .addComponent(jStockDetails2, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(88, Short.MAX_VALUE))
        );

        jProductsPanel3.setBackground(new java.awt.Color(255, 255, 153));
        jProductsPanel3.setForeground(new java.awt.Color(255, 255, 153));

        jLabel2.setText("Welcome  ");

        jusername.setText("username");

        jLabel24.setText("Email : ");

        jemail.setText("email");

        jLabel25.setText("Contact No : ");

        jContactNo.setText("Contact No");

        jLabel27.setText("Designation : ");

        jDesignation.setText("Designation");

        jLabel29.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel29.setText("---User Details--- ");

        javax.swing.GroupLayout jProductsPanel3Layout = new javax.swing.GroupLayout(jProductsPanel3);
        jProductsPanel3.setLayout(jProductsPanel3Layout);
        jProductsPanel3Layout.setHorizontalGroup(
            jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jProductsPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jProductsPanel3Layout.createSequentialGroup()
                        .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jusername, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jemail, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29)))
                    .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jProductsPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel27)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jDesignation, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jProductsPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel25)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jContactNo, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jProductsPanel3Layout.setVerticalGroup(
            jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jProductsPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel29)
                .addGap(18, 18, 18)
                .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jusername))
                .addGap(18, 18, 18)
                .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(jemail))
                .addGap(18, 18, 18)
                .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(jContactNo))
                .addGap(18, 18, 18)
                .addGroup(jProductsPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(jDesignation))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout jWelcomePanelLayout = new javax.swing.GroupLayout(jWelcomePanel);
        jWelcomePanel.setLayout(jWelcomePanelLayout);
        jWelcomePanelLayout.setHorizontalGroup(
            jWelcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jWelcomePanelLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(jWelcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProductsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jProductsPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(jWelcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jProductsPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jProductsPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );
        jWelcomePanelLayout.setVerticalGroup(
            jWelcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jWelcomePanelLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(jWelcomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jWelcomePanelLayout.createSequentialGroup()
                        .addComponent(jProductsPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(40, 40, 40)
                        .addComponent(jProductsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jWelcomePanelLayout.createSequentialGroup()
                        .addComponent(jProductsPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(jProductsPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 38, Short.MAX_VALUE))
        );

        jMainTabbedPane.addTab("Welcome", jWelcomePanel);

        jProductDetailsPanel.setBackground(new java.awt.Color(255, 255, 255));
        jProductDetailsPanel.setForeground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setForeground(new java.awt.Color(255, 255, 153));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel5.setText("Product Profile Viewer");

        jLoadFromFile.setText("Load Product Profiles");
        jLoadFromFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLoadFromFileActionPerformed(evt);
            }
        });

        jNextProductButton.setText("Next");
        jNextProductButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jNextProductButtonActionPerformed(evt);
            }
        });

        jPreviousProductButton.setText("Previous");
        jPreviousProductButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPreviousProductButtonActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 255, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setForeground(new java.awt.Color(255, 255, 51));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel19.setText("Advanced Search : - ");

        jIDSearchField.setText("Give a Product ID or Name");

        jSearchByIdBtn.setText("Search By ID");
        jSearchByIdBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchByIdBtnActionPerformed(evt);
            }
        });

        jLabel18.setText("Enter Product ID : -");

        jLabel17.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel17.setText("Search Options : ");

        jSearchCategoryField.setText("Enter Keyword - weight or price");
        jSearchCategoryField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jSearchCategoryFieldMouseEntered(evt);
            }
        });

        jSearchByAnythingButton.setText("Search By Weight/Price");
        jSearchByAnythingButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchByAnythingButtonActionPerformed(evt);
            }
        });

        jAssociatedValueField.setText("Enter weight or price range (0-1000 gms)");
        jAssociatedValueField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jAssociatedValueFieldMouseEntered(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel20.setText("*The Search Categories Available are ");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel21.setText("\"weight\" and \"price\" ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jIDSearchField)
                            .addComponent(jSearchCategoryField)
                            .addComponent(jAssociatedValueField)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addComponent(jSearchByAnythingButton))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addComponent(jSearchByIdBtn)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jIDSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jSearchByIdBtn)
                .addGap(18, 18, 18)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSearchCategoryField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jAssociatedValueField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSearchByAnythingButton)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel21))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLoadFromFile)
                        .addGap(83, 83, 83))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jNextProductButton)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jPreviousProductButton))))
                        .addGap(29, 29, 29))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel5)
                .addGap(41, 41, 41)
                .addComponent(jLoadFromFile)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jNextProductButton)
                    .addComponent(jPreviousProductButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setForeground(new java.awt.Color(255, 255, 153));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel6.setText("Add a New Product ");

        jPanel5.setBackground(new java.awt.Color(255, 255, 0));
        jPanel5.setForeground(new java.awt.Color(255, 255, 0));

        jLabel13.setText("Last Order Date (yyyy/mm/dd):");

        jLabel10.setText("<html> <u><b>price</b></u> (without VAT) : </html>");

        jLabel11.setText("<html><u><b>VAT</b></u> :</html>:");

        jLabel14.setText("Minimum Reorder Quantity :");

        jLabel7.setText("Porduct ID :");

        jLabel15.setText("<html>Display <u><b>picture</b></u> Name : </html>");

        jLabel16.setText("<html>Stock / <u><b> availableQuantity</b></u> : </html>");

        jLabel8.setText("Enter Product Name :");

        jSaveoFileButton.setText("Save To File");
        jSaveoFileButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveToFileButtonActionPerformed(evt);
            }
        });

        jLabel12.setText("Expiry Date (YYYY/MM/DD):");

        jLabel9.setText("Weight: ");

        jImageChooserButton.setText("jButton1");
        jImageChooserButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jImageChooserButtonActionPerformed(evt);
            }
        });

        jLabel22.setText("Manufactured By:");

        jProductId.setText(" ");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSaveoFileButton)
                .addGap(137, 137, 137))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(41, 41, 41))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPicture, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(jMinReorderQuantity)
                            .addComponent(jAmountInStock, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)
                            .addComponent(jLabel22)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jProductIdNewProduct)
                            .addComponent(jName)
                            .addComponent(jWeight)
                            .addComponent(jPrice)
                            .addComponent(jVAT)
                            .addComponent(jManufacturedBy)
                            .addComponent(jExpiry, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLastOrderDate, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProductId, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jImageChooserButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jProductId)
                    .addComponent(jProductIdNewProduct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jWeight, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jVAT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jManufacturedBy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jExpiry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLastOrderDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jMinReorderQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jImageChooserButton)
                    .addComponent(jPicture, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAmountInStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSaveoFileButton)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 30, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(103, 103, 103))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );

        javax.swing.GroupLayout jProductDetailsPanelLayout = new javax.swing.GroupLayout(jProductDetailsPanel);
        jProductDetailsPanel.setLayout(jProductDetailsPanelLayout);
        jProductDetailsPanelLayout.setHorizontalGroup(
            jProductDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jProductDetailsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jProductDetailsPanelLayout.setVerticalGroup(
            jProductDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jProductDetailsPanelLayout.createSequentialGroup()
                .addContainerGap(53, Short.MAX_VALUE)
                .addGroup(jProductDetailsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jMainTabbedPane.addTab("Product Details", jProductDetailsPanel);

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setForeground(new java.awt.Color(255, 255, 255));

        jPanel7.setBackground(new java.awt.Color(255, 255, 0));
        jPanel7.setForeground(new java.awt.Color(255, 255, 0));

        jLabel30.setText("Last Order Date : ");

        jLabel31.setText("price (without VAT) :");

        jLabel32.setText("VAT :");

        jLabel33.setText("Minimum Reorder Quanity :");

        jLabel34.setText("Product Id: ");

        jLabel35.setText("Display Picture Name :");

        jLabel36.setText("Stock / Available Qty : ");

        jLabel37.setText("Enter Product name");

        jSaveToFileButtonEditDetails.setText("Save Changes");
        jSaveToFileButtonEditDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveToFileButtonEditDetails(evt);
            }
        });

        jLabel38.setText("Expiry Date : ");

        jLabel39.setText("Weight(gms) :");

        jImageChooserButton1.setText("jButton1");
        jImageChooserButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jImageChooserButton1ActionPerformed(evt);
            }
        });

        jLabel40.setText("Manufactured By:");

        jProductId1.setText("   ");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel36)
                            .addComponent(jLabel35))
                        .addGap(40, 40, 40)))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPicture1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(jMinReorderQuantity1)
                    .addComponent(jAmountInStock1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jImageChooserButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel37)
                    .addComponent(jLabel34)
                    .addComponent(jLabel39)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32)
                    .addComponent(jLabel40)
                    .addComponent(jLabel38)
                    .addComponent(jLabel30))
                .addGap(44, 44, 44)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jName1)
                            .addComponent(jWeight1)
                            .addComponent(jPrice1)
                            .addComponent(jVAT1)
                            .addComponent(jManufacturedBy1)
                            .addComponent(jExpiry1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLastOrderDate1, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(47, 47, 47))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jProductId1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSaveToFileButtonEditDetails)
                .addGap(123, 123, 123))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(jProductId1))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel37)
                    .addComponent(jName1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jWeight1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel39))
                .addGap(14, 14, 14)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPrice1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jVAT1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel40)
                    .addComponent(jManufacturedBy1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jExpiry1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel38))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLastOrderDate1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jMinReorderQuantity1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jImageChooserButton1)
                    .addComponent(jPicture1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAmountInStock1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36))
                .addGap(30, 30, 30)
                .addComponent(jSaveToFileButtonEditDetails)
                .addGap(14, 14, 14))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 0));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.setForeground(new java.awt.Color(255, 255, 51));

        jSearchByIdBtnReorderTab.setText("Search By ID");
        jSearchByIdBtnReorderTab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchByIdBtnReorderTabActionPerformed(evt);
            }
        });

        jLabel42.setText("Enter Product ID 'OR' NAME : -");

        jLabel43.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel43.setText("Search Options : ");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jIDSearchField1, javax.swing.GroupLayout.PREFERRED_SIZE, 507, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                        .addComponent(jSearchByIdBtnReorderTab)
                        .addGap(26, 26, 26))))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jIDSearchField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSearchByIdBtnReorderTab))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jEditDetailsLayout = new javax.swing.GroupLayout(jEditDetails);
        jEditDetails.setLayout(jEditDetailsLayout);
        jEditDetailsLayout.setHorizontalGroup(
            jEditDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jEditDetailsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jEditDetailsLayout.setVerticalGroup(
            jEditDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jEditDetailsLayout.createSequentialGroup()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jMainTabbedPane.addTab("Edit Details", jEditDetails);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));

        jPanel9.setBackground(new java.awt.Color(255, 255, 0));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.setForeground(new java.awt.Color(255, 255, 51));

        jSearchByIdReorder.setText("Search By ID");
        jSearchByIdReorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchByIdReorderActionPerformed(evt);
            }
        });

        jLabel44.setText("Enter Product ID : -");

        jLabel45.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel45.setText("Search Options : ");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jIDSearchField2)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(236, 236, 236)
                .addComponent(jSearchByIdReorder)
                .addContainerGap(247, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jIDSearchField2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSearchByIdReorder)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jReOrder.setText("ReOrder");
        jReOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jReOrderActionPerformed(evt);
            }
        });

        jLabel41.setText("Product Name : - ");

        jLabel46.setText("Current Available Stock : -");

        jPurchaseAmountLabel.setText("Enter Purchase Quantity : - ");

        jLabel47.setText("Updated Stock : - ");

        jUpdatedStockOutput.setText("  ");

        jStockLevelOutput.setText("  ");

        jProductNameOutput.setText("  ");

        jButtonReorder.setText("Edit");
        jButtonReorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonReorderActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPurchaseAmountLabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel46, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel47, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jUpdatedStockOutput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPurchaseQtyField, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jStockLevelOutput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jProductNameOutput, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButtonReorder, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel41)
                    .addComponent(jProductNameOutput))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel46)
                    .addComponent(jStockLevelOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPurchaseAmountLabel)
                    .addComponent(jPurchaseQtyField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonReorder))
                .addGap(24, 24, 24)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel47)
                    .addComponent(jUpdatedStockOutput))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 94, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(227, 227, 227))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(315, 315, 315)
                .addComponent(jReOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jReOrder)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jReorderPanelLayout = new javax.swing.GroupLayout(jReorderPanel);
        jReorderPanel.setLayout(jReorderPanelLayout);
        jReorderPanelLayout.setHorizontalGroup(
            jReorderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jReorderPanelLayout.setVerticalGroup(
            jReorderPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jReorderPanelLayout.createSequentialGroup()
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 115, Short.MAX_VALUE))
        );

        jMainTabbedPane.addTab("Reorder", jReorderPanel);

        jPanel10.setBackground(new java.awt.Color(255, 255, 0));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel10.setForeground(new java.awt.Color(255, 255, 51));

        jSearchByIdBuyGoods.setText("Search By ID");
        jSearchByIdBuyGoods.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchByIdBuyGoodsActionPerformed(evt);
            }
        });

        jLabel48.setText("Enter Product ID  : - (Beta Version)");

        jLabel49.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel49.setText("Search Options : ");

        jupdatedStock.setForeground(new java.awt.Color(204, 204, 204));
        jupdatedStock.setText("   ");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jIDSearchField3)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(258, Short.MAX_VALUE)
                .addComponent(jSearchByIdBuyGoods)
                .addGap(161, 161, 161)
                .addComponent(jupdatedStock, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel48)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jIDSearchField3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jSearchByIdBuyGoods)
                    .addComponent(jupdatedStock))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        jLabel51.setText("Product Name : - ");

        jLabel52.setText("Current Available Stock : -");

        jPurchaseAmountLabel1.setText("Enter Purchase Quantity : - ");

        jStockLevelOutput1.setText("  ");

        jProductNameOutput1.setText("  ");

        jLabel57.setText("Total Price : -");

        jLabel58.setText("Date : -");

        jLabel59.setText("Time : -");

        jCurrentTimeLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jCurrentTimeLabel1.setForeground(new java.awt.Color(51, 51, 255));
        jCurrentTimeLabel1.setText("Time ");

        jCurrentDateLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jCurrentDateLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jCurrentDateLabel1.setText("Date");

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 51, 51));
        jLabel60.setText("<html><u>BILL INVOICE</u></html>");

        jButtonBuyGoods.setText("Edit");
        jButtonBuyGoods.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuyGoodsActionPerformed(evt);
            }
        });

        jTotalPriceOutput.setText("   ");

        jLabel61.setText("Price For 1 :-");

        jPriceFor1Output.setText("     ");

        jLabel53.setText("VAT : -");

        jVatOutput.setText("   ");

        jLabel62.setText("Price With VAT : -");

        jPriceWithVatOutput.setText("    ");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jCurrentTimeLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jCurrentDateLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addGap(0, 37, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel57)
                            .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(82, 82, 82)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jVatOutput, javax.swing.GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE)
                            .addComponent(jTotalPriceOutput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jPurchaseAmountLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel52, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel51, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel62))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jPurchaseQtyField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jStockLevelOutput1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jProductNameOutput1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButtonBuyGoods))
                            .addComponent(jPriceWithVatOutput, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPriceFor1Output, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(33, 33, 33))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel58)
                    .addComponent(jCurrentDateLabel1))
                .addGap(4, 4, 4)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(jCurrentTimeLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel51)
                    .addComponent(jProductNameOutput1))
                .addGap(27, 27, 27)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel52)
                    .addComponent(jStockLevelOutput1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPurchaseAmountLabel1)
                    .addComponent(jPurchaseQtyField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonBuyGoods))
                .addGap(21, 21, 21)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(jPriceFor1Output))
                .addGap(27, 27, 27)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel57)
                    .addComponent(jTotalPriceOutput))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel53)
                    .addComponent(jVatOutput))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel62)
                    .addComponent(jPriceWithVatOutput))
                .addGap(47, 47, 47))
        );

        jPurchaseBG.setText("Purchase");
        jPurchaseBG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPurchaseBGActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jSalesPanelLayout = new javax.swing.GroupLayout(jSalesPanel);
        jSalesPanel.setLayout(jSalesPanelLayout);
        jSalesPanelLayout.setHorizontalGroup(
            jSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jSalesPanelLayout.createSequentialGroup()
                .addGroup(jSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jSalesPanelLayout.createSequentialGroup()
                        .addGap(305, 305, 305)
                        .addComponent(jPurchaseBG, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jSalesPanelLayout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(97, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jSalesPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(160, 160, 160))
        );
        jSalesPanelLayout.setVerticalGroup(
            jSalesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jSalesPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(jPurchaseBG)
                .addGap(29, 29, 29))
        );

        jMainTabbedPane.addTab("Buy Goods", jSalesPanel);

        jPanel14.setBackground(new java.awt.Color(255, 255, 0));
        jPanel14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel14.setForeground(new java.awt.Color(255, 255, 51));

        jSearchByIdBtnDeleteProducts.setText("Search By ID");
        jSearchByIdBtnDeleteProducts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSearchByIdBtnDeleteProductsActionPerformed(evt);
            }
        });

        jLabel50.setText("Enter Product ID : -");

        jLabel54.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel54.setText("Search Options : ");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(jIDSearchField4, javax.swing.GroupLayout.PREFERRED_SIZE, 507, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                        .addComponent(jSearchByIdBtnDeleteProducts)
                        .addGap(26, 26, 26))))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel50)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jIDSearchField4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSearchByIdBtnDeleteProducts))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jLabel55.setText("Product Name : - ");

        jLabel56.setText("Current Available Stock : -");

        jStockLevelOutput2.setText("  ");

        jProductNameOutput2.setText("  ");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(66, Short.MAX_VALUE)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel56, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel55, javax.swing.GroupLayout.Alignment.LEADING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jStockLevelOutput2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jProductNameOutput2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel55)
                    .addComponent(jProductNameOutput2))
                .addGap(18, 18, 18)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel56)
                    .addComponent(jStockLevelOutput2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        jDelButton1.setText("Delete");
        jDelButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDelButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jDeletePanelLayout = new javax.swing.GroupLayout(jDeletePanel);
        jDeletePanel.setLayout(jDeletePanelLayout);
        jDeletePanelLayout.setHorizontalGroup(
            jDeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDeletePanelLayout.createSequentialGroup()
                .addGroup(jDeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jDeletePanelLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jDeletePanelLayout.createSequentialGroup()
                        .addGap(344, 344, 344)
                        .addComponent(jDelButton1)))
                .addContainerGap(43, Short.MAX_VALUE))
            .addGroup(jDeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jDeletePanelLayout.createSequentialGroup()
                    .addGap(179, 179, 179)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(180, Short.MAX_VALUE)))
        );
        jDeletePanelLayout.setVerticalGroup(
            jDeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDeletePanelLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(199, 199, 199)
                .addComponent(jDelButton1)
                .addContainerGap(262, Short.MAX_VALUE))
            .addGroup(jDeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jDeletePanelLayout.createSequentialGroup()
                    .addGap(237, 237, 237)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(319, Short.MAX_VALUE)))
        );

        jMainTabbedPane.addTab("Delete Products", jDeletePanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jMainTabbedPane)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jMainTabbedPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRegisterUserButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegisterUserButtonActionPerformed
        // TODO add your handling code here:
        register obj = new register();
        obj.setVisible(true);
        dispose();
    }//GEN-LAST:event_jRegisterUserButtonActionPerformed

    private void jLoadFromFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLoadFromFileActionPerformed
        // TODO add your handling code here:
        productsList.startDisplay();
        
        
    }//GEN-LAST:event_jLoadFromFileActionPerformed

    private void jNextProductButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jNextProductButtonActionPerformed
        // TODO add your handling code here:
        productsList.nextDisplay(jNextProductButton);
    }//GEN-LAST:event_jNextProductButtonActionPerformed

    private void jSaveToFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSaveToFileButtonActionPerformed
        // TODO add your handling code here:
        if(jProductIdNewProduct.getText().equals("") || jName.getText().equals("") || jWeight.getText().equals("") || jPrice.getText().equals("") || jVAT.getText().equals("") || jManufacturedBy.getText().equals("") ||jExpiry.getText().equals("") || jLastOrderDate.getText().equals("") || jMinReorderQuantity.getText().equals("") || jPicture.getText().equals("") || jAmountInStock.getText().equals("") ){
            JOptionPane.showMessageDialog(null, "You cannot leave the field empty must provide values for every field !!!");
        }
        
        else{
                if(productsList.saveToFile(jProductIdNewProduct.getText(), jName.getText(), jWeight.getText(), jPrice.getText(), jVAT.getText(), jManufacturedBy.getText(),jExpiry.getText(), jLastOrderDate.getText(), jMinReorderQuantity.getText(), jPicture.getText(), jAmountInStock.getText(), true) &&
           productsList.updateFile(jProductIdNewProduct.getText(), jName.getText(), jWeight.getText(), jPrice.getText(), jVAT.getText(),jManufacturedBy.getText(), jExpiry.getText(), jLastOrderDate.getText(), jMinReorderQuantity.getText(), jPicture.getText(), jAmountInStock.getText()) ){
            JOptionPane.showMessageDialog(null, "Success");
        }else{
            JOptionPane.showMessageDialog(null, "Error");
        }
                }
    }//GEN-LAST:event_jSaveToFileButtonActionPerformed

    private void jImageChooserButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jImageChooserButtonActionPerformed
        // TODO add your handling code here:
        int returnValue = openFileChooser.showOpenDialog(this);
        
        if (returnValue == JFileChooser.APPROVE_OPTION){
            try{
                File theFile = openFileChooser.getSelectedFile();
                File target = new File(theFile.getName());
                Files.copy(theFile.toPath(),target.toPath());
                jPicture.setText(theFile.getName());
                JOptionPane.showMessageDialog(null, "Success");
            }catch(IOException e){
                            JOptionPane.showMessageDialog(null, "Failed To load Image File");

            }
            
        }
        else{
            JOptionPane.showMessageDialog(null, "Error");
        }
    }//GEN-LAST:event_jImageChooserButtonActionPerformed

    private void jPreviousProductButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPreviousProductButtonActionPerformed
        // TODO add your handling code here:
        productsList.prevDisplay();
    }//GEN-LAST:event_jPreviousProductButtonActionPerformed

    private void jSearchByIdBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchByIdBtnActionPerformed
        // TODO add your handling code here:
        if(jIDSearchField.getText().equals("") ){
            JOptionPane.showMessageDialog(null, "The search field is empty please give a valid Id to search Products List.");
        }
        else{
            try{
                productsList.searchByID(jIDSearchField.getText());
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "You have to enter a Valid Id to continue");
            }
        
        }
    }//GEN-LAST:event_jSearchByIdBtnActionPerformed

    private void jSearchByAnythingButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchByAnythingButtonActionPerformed
        // TODO add your handling code here:
        FilteredTable T1 = new FilteredTable();
        
        if(jSearchCategoryField.getText().equals("")||jAssociatedValueField.getText().equals("") ){
            JOptionPane.showMessageDialog(null, "You cannot leaves the fields empty to search a product");
        }
        else{
        try{
        if(productsList.searchByAnything(jSearchCategoryField.getText(), jAssociatedValueField.getText(), T1)){
        T1.setVisible(true);
        }
        else{
            JOptionPane.showMessageDialog(null, "Error");
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Your search did not match any product please enter relevant data !!!");
        }
        }
    }//GEN-LAST:event_jSearchByAnythingButtonActionPerformed

    private void jSearchCategoryFieldMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jSearchCategoryFieldMouseEntered
        // TODO add your handling code here:
        jSearchCategoryField.setText("");
    }//GEN-LAST:event_jSearchCategoryFieldMouseEntered

    private void jAssociatedValueFieldMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jAssociatedValueFieldMouseEntered
        // TODO add your handling code here:
        jAssociatedValueField.setText("");
    }//GEN-LAST:event_jAssociatedValueFieldMouseEntered
   
   
    
    private void jLoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLoginButtonActionPerformed

        
        try{
            
            
         // User Details Panel Setup
        String [] details1 = theUser.getDetails();
        User newUser = new User();
        try {
            newUser = newUser.getUser(jUserNameField.getText());
        } catch (IOException ex) {
            Logger.getLogger(MainJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        jusername.setText(newUser.getUserID());
        jemail.setText(newUser.getEmail());
        jContactNo.setText(newUser.getContactNo());
        jDesignation.setText(newUser.getDesignation());
            
             int login = this.getIndexByName("Login");
        if (jUserNameField.getText().equals("") || String.valueOf(jPasswordField).equals("")){
                    JOptionPane.showMessageDialog(null, "You must Enter Valid Credentials to continue !");
                    jMainTabbedPane.setSelectedIndex(login);
          
                    }
            
        
            // In Case the user is a Manager 
            
            if (theUser.verifyUser(jUserNameField.getText(), String.valueOf(jPasswordField.getPassword()))){
                
                            // If Login successful then 
                           if( theUser.checkDesignation(jUserNameField.getText(), String.valueOf(jPasswordField.getPassword()), "Owner")){
                           
                           // Disabling the Login
                           int lgIndex = this.getIndexByName("Login");
                           jMainTabbedPane.setEnabledAt(lgIndex, false);
                           

                           // Which tabs will be Visible to Owner
                           jMainTabbedPane.addTab("Welcome",jTabInMemoryWelcome);
                           jMainTabbedPane.addTab("Products Details",jTabInMemoryProductDetails);
                           jMainTabbedPane.addTab("Reorder",jTabInMemoryReorder);
                           jMainTabbedPane.addTab("Buy Goods",jTabInMemoryBuyGoods);
                           jMainTabbedPane.addTab("Edit Details", jTabInMemoryEditDetails);
                           jMainTabbedPane.addTab("Delete Products", jTabInMemoryDeleteProducts);
                           

                           // Selecting the starting Tab
                           int wpIndex = this.getIndexByName("Welcome");
                           jMainTabbedPane.setSelectedIndex(wpIndex);

                            }

                        // In case the User is Admininstrator 
                        else if(theUser.checkDesignation(jUserNameField.getText(), String.valueOf(jPasswordField.getPassword()), "Administrator")){
                            // Disabling the Login
                           int lgIndex = this.getIndexByName("Login");
                           jMainTabbedPane.setEnabledAt(lgIndex, false);
                            
                            
                           // Which tabs will be Visible to Admin - It makes sense that an admin should not be allowed to reorder stock
                           jMainTabbedPane.addTab("Welcome",jTabInMemoryWelcome);
                           jMainTabbedPane.addTab("Products Details",jTabInMemoryProductDetails);
                           
                           

                           // Selecting the starting Tab
                           int wpIndex = this.getIndexByName("Welcome");
                           jMainTabbedPane.setSelectedIndex(wpIndex);
                         }
                           
                          // In case the User is Customer
                        else if(theUser.checkDesignation(jUserNameField.getText(), String.valueOf(jPasswordField.getPassword()), "Customer")){
                            // Disabling the Login
                           int lgIndex = this.getIndexByName("Login");
                           jMainTabbedPane.setEnabledAt(lgIndex, false);
                            
                            
                           // Which tabs will be Visible to Customer
                           jMainTabbedPane.addTab("Buy Goods",jTabInMemoryBuyGoods);
                           

                           // Selecting the starting Tab
                           int wpIndex = this.getIndexByName("Buy Goods");
                           jMainTabbedPane.setSelectedIndex(wpIndex);
                         }
                           
                         
                   
            }
            
            // Outer Main Else    
            else {
                        
                        JOptionPane.showMessageDialog(this, "Wrong credentials have been entered.");
                }
                
                
        }catch (IOException ex) {
            Logger.getLogger(MainJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jLoginButtonActionPerformed

    private void jSaveToFileButtonEditDetails(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSaveToFileButtonEditDetails
        // TODO add your handling code here:
        if(jProductId1.getText().equals("") || jName1.getText().equals("") || jWeight1.getText().equals("") || jPrice1.getText().equals("") || jVAT1.getText().equals("") || jManufacturedBy1.getText().equals("") || jExpiry1.getText().equals("") || jLastOrderDate1.getText().equals("") || jMinReorderQuantity1.getText().equals("") ||jPicture1.getText().equals("") ||jAmountInStock1.getText().equals("") ){
            JOptionPane.showMessageDialog(null, "You cant leave the field empty , you must provide non-empty values");
        }
        else{
        try{
        product auxi= new product();
        productsList updated = new productsList();
        auxi = productsList.searchByIDgetProduct(jProductId1.getText());
        productsList.deleteProduct(auxi);
        productsList.saveToFile(); 
        productsList.saveToFile(jProductId1.getText(),jName1.getText(),jWeight1.getText(),jPrice1.getText(),jVAT1.getText(),jManufacturedBy1.getText(),jExpiry1.getText(),jLastOrderDate1.getText(),jMinReorderQuantity1.getText(),jPicture1.getText(),jAmountInStock1.getText(), true);
                 
        
        updated = productsList.loadFromFileGetList();
        updated.sortById();
        
        productsList = updated;
        productsList.saveToFile();
              
       
              JOptionPane.showMessageDialog(null, "The product has been Updated Successfully.");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error" + e.toString());
        }
          
          // Firstly the old product will be deleted
          
        }  
           
    }//GEN-LAST:event_jSaveToFileButtonEditDetails

    private void jImageChooserButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jImageChooserButton1ActionPerformed
        // TODO add your handling code here:
         int returnValue = openFileChooser.showOpenDialog(this);
        
        if (returnValue == JFileChooser.APPROVE_OPTION){
            try{
                File theFile = openFileChooser.getSelectedFile();
                File target = new File(theFile.getName());
                Files.copy(theFile.toPath(),target.toPath());
                jPicture.setText(theFile.getName());
                JOptionPane.showMessageDialog(null, "Success");
            }catch(IOException e){
                            JOptionPane.showMessageDialog(null, "Failed To load Image File");

            }
            
        }
        else{
            JOptionPane.showMessageDialog(null, "Error");
        }
    }//GEN-LAST:event_jImageChooserButton1ActionPerformed

    private void jSearchByIdBtnReorderTabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchByIdBtnReorderTabActionPerformed
        // TODO add your handling code here:
         try{
        if(jIDSearchField1.getText().equals("")){
            JOptionPane.showMessageDialog(null, "You cannot enter empty field values in this search bar");
        }else{
           
        product auxi= new product();
        auxi = productsList.searchByIDgetProduct(jIDSearchField1.getText());
        if(auxi.getID() == -1){
            String message = String.format("There is no product with the ID %d", auxi.getID());
                JOptionPane.showMessageDialog(null, message);
                
            
        }else{
        jProductId1.setText(String.valueOf(auxi.getID()));
        jName1.setText(auxi.getName());
        jWeight1.setText(String.valueOf(auxi.getWeight()));
        jPrice1.setText(String.valueOf(auxi.getPrice()));
        jVAT1.setText(String.valueOf(auxi.getVAT()));
        jManufacturedBy1.setText(auxi.getManufacturerName());
        jExpiry1.setText(String.valueOf(auxi.getExpiryDate()));
        jLastOrderDate1.setText(String.valueOf(auxi.getLastOrderDate()));
        jMinReorderQuantity1.setText(String.valueOf(auxi.getReorderQuantity()));
        jPicture1.setText(auxi.getPicture());
        jAmountInStock1.setText(String.valueOf(auxi.getAvailableQuantity()));
        }
        }
         
         }catch(NumberFormatException nfe){
               JOptionPane.showMessageDialog(null, "You have entered a string please procide valid ID");
            }
        
    }//GEN-LAST:event_jSearchByIdBtnReorderTabActionPerformed

    private void jSearchByIdReorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchByIdReorderActionPerformed
        // TODO add your handling code here:#
        try{
        if(jIDSearchField2.getText().equals("") ){
           JOptionPane.showMessageDialog(null, "Search Field Cannot be Empty"); 
        }
       
        else{
        product auxi= new product();
        auxi = productsList.searchByIDgetProduct(jIDSearchField2.getText());
        if(auxi.getID() == -1){
            String message = String.format("There is no product with the ID %d", auxi.getID());
                JOptionPane.showMessageDialog(null, message);
                
            
        }else{
             boolean flag= true;
        String val="";
        while(flag){
        try{
             jProductNameOutput.setText(auxi.getName());
            jStockLevelOutput.setText(String.valueOf(auxi.getAvailableQuantity()));
            val = JOptionPane.showInputDialog(null,String.format("Enter the amount of %s you wish to reorder ?", auxi.getName()));
            Integer.parseInt(val);
             
            flag = false;
        } catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You Provided Invalid Entry please give valid Entry");
        }
        }
       
        
        jProductNameOutput.setText(auxi.getName());
        jStockLevelOutput.setText(String.valueOf(auxi.getAvailableQuantity()));
        jPurchaseQtyField.setText(val);
        String updatedStock = String.valueOf( auxi.getAvailableQuantity() + Integer.parseInt(jPurchaseQtyField.getText()));
        jUpdatedStockOutput.setText(updatedStock);
        jReOrder.setEnabled(true);
        }
        }
        }catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You tired to enter a String, please give valid entries");
        }
    }//GEN-LAST:event_jSearchByIdReorderActionPerformed

    private void jSearchByIdBuyGoodsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchByIdBuyGoodsActionPerformed
        // TODO add your handling code here:
        try{
        if(jIDSearchField3.getText().equals("")){
             JOptionPane.showMessageDialog(null, "Search Field Cannot be Empty"); 
        }
        
        else{
        product auxi= new product();
        auxi = productsList.searchByIDgetProduct(jIDSearchField3.getText());
        if(auxi.getID() == -1){
            String message = String.format("There is no product with the ID %s", jIDSearchField3.getText());
                JOptionPane.showMessageDialog(null, message);
                
            
        }else{
            
       
        
        boolean flag= true;
        String val="";
        while(flag){
        try{
             jProductNameOutput1.setText(auxi.getName());
            jStockLevelOutput1.setText(String.valueOf(auxi.getAvailableQuantity()));
            val = JOptionPane.showInputDialog(null,String.format("Enter the amount of %s you wish to reorder ?", auxi.getName()));
            Integer.parseInt(val);
             while(Integer.parseInt(val)>auxi.getAvailableQuantity()){
            JOptionPane.showMessageDialog(null, "You can't buy more than the available quantity ?"); 
             val = "";
             val = JOptionPane.showInputDialog(null,String.format("Enter the amount of %s you wish to reorder ?", auxi.getName()));
        }
            flag = false;
        } catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You tired to enter a String, please give valid entries");
        }
        }
       
        String updateStock = String.valueOf(auxi.getAvailableQuantity()- Integer.parseInt(val));
        jupdatedStock.setText(updateStock);
        jPurchaseQtyField1.setText(val);
        String BillValue = String.valueOf(Integer.parseInt(val) * auxi.getPrice());
        jPriceFor1Output.setText(String.valueOf(auxi.getPrice()));
        jTotalPriceOutput.setText(BillValue);
        jVatOutput.setText(String.valueOf(auxi.getVAT()));
        jPriceWithVatOutput.setText(String.valueOf(((auxi.getVAT()/100)* Double.parseDouble(BillValue)) + Double.parseDouble(BillValue)));
        jPurchaseBG.setEnabled(true);
        }
        }
        }catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You tired to enter a String, please give valid entries");
        }
    }//GEN-LAST:event_jSearchByIdBuyGoodsActionPerformed

    private void jReOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jReOrderActionPerformed
        // TODO add your handling code here:
        product auxi= new product();
        productsList updated = new productsList();
        auxi = productsList.searchByIDgetProduct(jIDSearchField2.getText());
        productsList.deleteProduct(auxi);
        productsList.saveToFile(); 
        productsList.saveToFile(String.valueOf(auxi.getID()),
                               auxi.getName(),
                               String.valueOf(auxi.getWeight()),
                               String.valueOf(auxi.getPrice()),
                               String.valueOf(auxi.getVAT()),
                               String.valueOf(auxi.getManufacturerName()),
                               String.valueOf(auxi.getExpiryDate()),
                               String.valueOf(auxi.getLastOrderDate()),
                               String.valueOf(auxi.getReorderQuantity()),
                               String.valueOf(auxi.getPicture()),
                               jUpdatedStockOutput.getText(), true);
        
        updated = productsList.loadFromFileGetList();
        updated.sortById();
        
        productsList = updated;
        productsList.saveToFile();
              
        JOptionPane.showMessageDialog(null, "The product has been Updated Successfully.");
          
    }//GEN-LAST:event_jReOrderActionPerformed

    private void jPurchaseBGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPurchaseBGActionPerformed
        // TODO add your handling code here:
         product auxi= new product();
        productsList updated = new productsList();
        auxi = productsList.searchByIDgetProduct(jIDSearchField3.getText());
        productsList.deleteProduct(auxi);
        productsList.saveToFile(); 
        productsList.saveToFile(String.valueOf(auxi.getID()),
                               auxi.getName(),
                               String.valueOf(auxi.getWeight()),
                               String.valueOf(auxi.getPrice()),
                               String.valueOf(auxi.getVAT()),
                               String.valueOf(auxi.getManufacturerName()),
                               String.valueOf(auxi.getExpiryDate()),
                               String.valueOf(auxi.getLastOrderDate()),
                               String.valueOf(auxi.getReorderQuantity()),
                               String.valueOf(auxi.getPicture()),
                               jupdatedStock.getText(), true);
        
        updated = productsList.loadFromFileGetList();
        updated.sortById();
        
        productsList = updated;
        productsList.saveToFile();
              
        JOptionPane.showMessageDialog(null, "Thank You for your purchase.");
          
    }//GEN-LAST:event_jPurchaseBGActionPerformed

    private void jSearchByIdBtnDeleteProductsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSearchByIdBtnDeleteProductsActionPerformed
        // TODO add your handling code here:
        try{
        if(jIDSearchField4.getText().equals("")){
           JOptionPane.showMessageDialog(null, "Search Field Cannot be Empty");  
        }
        
        else{
         product auxi= new product();
        auxi = productsList.searchByIDgetProduct(jIDSearchField4.getText());
        if(auxi.getID() == -1){
            String message = String.format("There is no product with the ID %s", jIDSearchField4.getText());
                JOptionPane.showMessageDialog(null, message);
                
            
        }else{
        jDelButton1.setEnabled(true);
        jProductNameOutput2.setText(auxi.getName());
        jStockLevelOutput2.setText(String.valueOf(auxi.getAvailableQuantity()));
        }
        }
        }catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You tired to enter a String, please give valid entries");
        }
    }//GEN-LAST:event_jSearchByIdBtnDeleteProductsActionPerformed

    private void jDelButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDelButton1ActionPerformed
        // TODO add your handling code here:
         product auxi= new product();
        productsList updated = new productsList();
        auxi = productsList.searchByIDgetProduct(jIDSearchField4.getText());
        productsList.deleteProduct(auxi);
        productsList.saveToFile(); 
       
        
        updated = productsList.loadFromFileGetList();
        updated.sortById();
        
        productsList = updated;
        productsList.saveToFile();
              
        JOptionPane.showMessageDialog(null, "The product has been Deleted Successfully.");
    }//GEN-LAST:event_jDelButton1ActionPerformed

    private void jButtonReorderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonReorderActionPerformed
        // TODO add your handling code here:
         product auxi= new product();
        auxi = productsList.searchByIDgetProduct(jIDSearchField2.getText());
        boolean flag= true;
        String val="";
        while(flag){
        try{
            val = JOptionPane.showInputDialog(null,String.format("Please Re-Enter a suitable Quantity value "));
            Integer.parseInt(val);
            
            flag = false;
        } catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You tired to enter a String, please give valid entries");
        }
        }
        
        
        jPurchaseQtyField.setText(val);
        jUpdatedStockOutput.setText(String.valueOf(auxi.getAvailableQuantity() + Integer.parseInt(val)));
         jReOrder.setEnabled(true);
    }//GEN-LAST:event_jButtonReorderActionPerformed

    private void jButtonBuyGoodsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBuyGoodsActionPerformed
        // TODO add your handling code here:
        product auxi= new product();
        auxi = productsList.searchByIDgetProduct(jIDSearchField3.getText());
        boolean flag= true;
        String val="";
        while(flag){
        try{
            val = JOptionPane.showInputDialog(null,String.format("Please Re-Enter a suitable Quantity value "));
            Integer.parseInt(val);
            while(Integer.parseInt(val)>auxi.getAvailableQuantity()){
            JOptionPane.showMessageDialog(null, "You can't buy more than the available quantity ?"); 
             val = "";
             val = JOptionPane.showInputDialog(null,String.format("Enter the amount of %s you wish to reorder ?", auxi.getName()));
            }
            
            flag = false;
        } catch(NumberFormatException nfe){
            JOptionPane.showInternalMessageDialog(null, "You tired to enter a String, please give valid entries");
        }
        }
        
        
        String updateStock = String.valueOf(auxi.getAvailableQuantity()- Integer.parseInt(val));
        jupdatedStock.setText(updateStock);
        jPurchaseQtyField1.setText(val);
        String BillValue = String.valueOf(Integer.parseInt(val) * auxi.getPrice());
        jPriceFor1Output.setText(String.valueOf(auxi.getPrice()));
        jTotalPriceOutput.setText(BillValue);
        jVatOutput.setText(String.valueOf(auxi.getVAT()));
        jPriceWithVatOutput.setText(String.valueOf(((auxi.getVAT()/100)* Double.parseDouble(BillValue)) + Double.parseDouble(BillValue)));
        jPurchaseBG.setEnabled(true);
    }//GEN-LAST:event_jButtonBuyGoodsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField jAmountInStock;
    private javax.swing.JTextField jAmountInStock1;
    private javax.swing.JTextField jAssociatedValueField;
    private javax.swing.JLabel jAvailableProductsOutput;
    private javax.swing.JButton jButtonBuyGoods;
    private javax.swing.JButton jButtonReorder;
    private javax.swing.JLabel jContactNo;
    private javax.swing.JLabel jCurrentDateLabel;
    private javax.swing.JLabel jCurrentDateLabel1;
    private javax.swing.JLabel jCurrentTimeLabel;
    private javax.swing.JLabel jCurrentTimeLabel1;
    private javax.swing.JButton jDelButton1;
    private javax.swing.JPanel jDeletePanel;
    private javax.swing.JLabel jDesignation;
    private javax.swing.JPanel jEditDetails;
    private javax.swing.JLabel jEnterPasswordLabel;
    private javax.swing.JLabel jEnterUsernameLabel;
    private javax.swing.JLabel jExpiredItemsOutput;
    private javax.swing.JTextField jExpiry;
    private javax.swing.JTextField jExpiry1;
    private javax.swing.JLabel jIDLabel;
    private javax.swing.JTextField jIDSearchField;
    private javax.swing.JTextField jIDSearchField1;
    private javax.swing.JTextField jIDSearchField2;
    private javax.swing.JTextField jIDSearchField3;
    private javax.swing.JTextField jIDSearchField4;
    private javax.swing.JButton jImageChooserButton;
    private javax.swing.JButton jImageChooserButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jLastOrderDate;
    private javax.swing.JTextField jLastOrderDate1;
    private javax.swing.JButton jLoadFromFile;
    private javax.swing.JLabel jLocationNameOutput;
    private javax.swing.JButton jLoginButton;
    private javax.swing.JPanel jLoginPanel;
    private javax.swing.JLabel jMainLogoPosterLabel;
    private javax.swing.JTabbedPane jMainTabbedPane;
    private javax.swing.JTextField jManufacturedBy;
    private javax.swing.JTextField jManufacturedBy1;
    private javax.swing.JTextField jMinReorderQuantity;
    private javax.swing.JTextField jMinReorderQuantity1;
    private javax.swing.JTextField jName;
    private javax.swing.JTextField jName1;
    private javax.swing.JLabel jNearExpiryOutput;
    private javax.swing.JButton jNextProductButton;
    private javax.swing.JLabel jOwnerNameOutput;
    private javax.swing.JLabel jPNMQOutput1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField;
    private javax.swing.JTextField jPicture;
    private javax.swing.JTextField jPicture1;
    private javax.swing.JButton jPreviousProductButton;
    private javax.swing.JTextField jPrice;
    private javax.swing.JTextField jPrice1;
    private javax.swing.JLabel jPriceFor1Output;
    private javax.swing.JLabel jPriceLabel;
    private javax.swing.JLabel jPriceWithVatOutput;
    private javax.swing.JPanel jProductDetailsPanel;
    private javax.swing.JLabel jProductId;
    private javax.swing.JLabel jProductId1;
    private javax.swing.JTextField jProductIdNewProduct;
    private javax.swing.JLabel jProductNameOutput;
    private javax.swing.JLabel jProductNameOutput1;
    private javax.swing.JLabel jProductNameOutput2;
    private javax.swing.JLabel jProductNearingMinQtyLabel;
    private javax.swing.JLabel jProductNearingMinQtyLabel1;
    private javax.swing.JPanel jProductsPanel;
    private javax.swing.JPanel jProductsPanel1;
    private javax.swing.JPanel jProductsPanel2;
    private javax.swing.JPanel jProductsPanel3;
    private javax.swing.JLabel jPurchaseAmountLabel;
    private javax.swing.JLabel jPurchaseAmountLabel1;
    private javax.swing.JButton jPurchaseBG;
    private javax.swing.JTextField jPurchaseQtyField;
    private javax.swing.JTextField jPurchaseQtyField1;
    private javax.swing.JButton jReOrder;
    private javax.swing.JButton jRegisterUserButton;
    private javax.swing.JPanel jReorderPanel;
    private javax.swing.JPanel jSalesPanel;
    private javax.swing.JButton jSaveToFileButtonEditDetails;
    private javax.swing.JButton jSaveoFileButton;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JButton jSearchByAnythingButton;
    private javax.swing.JButton jSearchByIdBtn;
    private javax.swing.JButton jSearchByIdBtnDeleteProducts;
    private javax.swing.JButton jSearchByIdBtnReorderTab;
    private javax.swing.JButton jSearchByIdBuyGoods;
    private javax.swing.JButton jSearchByIdReorder;
    private javax.swing.JTextField jSearchCategoryField;
    private javax.swing.JPanel jStockDetails;
    private javax.swing.JPanel jStockDetails1;
    private javax.swing.JPanel jStockDetails2;
    private javax.swing.JLabel jStockLevelOutput;
    private javax.swing.JLabel jStockLevelOutput1;
    private javax.swing.JLabel jStockLevelOutput2;
    private javax.swing.JLabel jStockValueOutput;
    private javax.swing.JLabel jTAPOutput1;
    private javax.swing.JLabel jTotalAvailableProductsLabel;
    private javax.swing.JLabel jTotalAvailableProductsLabel1;
    private javax.swing.JLabel jTotalCashSaleOutput;
    private javax.swing.JLabel jTotalNonCashSaleOutput;
    private javax.swing.JLabel jTotalPriceLabel;
    private javax.swing.JLabel jTotalPriceOutput;
    private javax.swing.JLabel jTotalStockQuantity;
    private javax.swing.JLabel jUpdatedStockOutput;
    private javax.swing.JTextField jUserNameField;
    private javax.swing.JTextField jVAT;
    private javax.swing.JTextField jVAT1;
    private javax.swing.JLabel jVATLabel;
    private javax.swing.JLabel jVatOutput;
    private javax.swing.JTextField jWeight;
    private javax.swing.JTextField jWeight1;
    private javax.swing.JLabel jWeightLabel;
    private javax.swing.JPanel jWelcomePanel;
    private javax.swing.JLabel jemail;
    private javax.swing.JLabel jupdatedStock;
    private javax.swing.JLabel jusername;
    private hypermart.product product1;
    private hypermart.product product2;
    // End of variables declaration//GEN-END:variables

    public JTabbedPane getjMainTabbedPane() {
        return jMainTabbedPane;
    }
}
