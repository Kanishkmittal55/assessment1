package hypermart;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.time.Month;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 44789
 */
public class User{
    private String designation;
    private String UserID;
    private String firstName;
    private String surName;
    private String Email;
    private String contactNo;
    private LocalDate DOB;
    private String password;
   
    
//    private int Length;
    
//    File f = new File("C:\\Users\\44789\\Desktop\\EE2606\\Lab3"); 
    
    public User(String UserID,String thefirstName,String theSurName,String thedesignation, String theEmail,String theContactNo, String thePassword, LocalDate DOB) {
        this.UserID = UserID;
        firstName = thefirstName;
        surName = theSurName;
        designation = thedesignation;
        Email = theEmail;
        contactNo = theContactNo;
        password = thePassword;
        this.DOB = DOB;
        
    }

    public String getDesignation() {
        return designation;
    }

    public String getUserID() {
        return UserID;
    }

    public String getEmail() {
        return Email;
    }

    public String getContactNo() {
        return contactNo;
    }
    
    public User(){
        this.UserID = "JohnDoe";
        firstName = "John";
        surName = "Doe";
        designation = "Onwer";
        Email = "dummy@gmail.com";
        contactNo = "100";
        password = "1234";
        this.DOB = LocalDate.of(1990, 12, 30);
    }
    
    public void Edit(String UserID,String thefirstName,String theSurName,String thedesignation, String theEmail,String theContactNo, String thePassword, LocalDate DOB){
        this.UserID = UserID;
        firstName = thefirstName;
        surName = theSurName;
        designation = thedesignation;
        Email = theEmail;
        contactNo = theContactNo;
        password = thePassword;
        this.DOB = DOB;
    }
    
    public String getUserId(){
        return this.UserID;
    }
    

    
     public int CountLines() throws IOException{
       
            File file = new File("loginDetails.txt");
            
             BufferedReader bufReader = new BufferedReader(new FileReader(file));
             String line = bufReader.readLine(); 
            int count =0;
             while (line != null) { 
                line = bufReader.readLine();
                count++; 
             }
            bufReader.close();           
        return count;
    }

    

    

    
     public boolean RegisterNewUser (boolean append,String Designation, String userId, String strFirstName,String strSurName, String strEmail,String strContactNo ,String strPassword,String strDOB) throws IOException{
        boolean isRegistered = false;
        
        designation = Designation;
        UserID = userId;
        firstName = strFirstName;
        surName = strSurName;
        Email = strEmail;
        contactNo = strContactNo;
        password = strPassword;
        DOB = LocalDate.parse(strDOB);
        
        try {
            FileWriter theWriter;
            
            theWriter = new FileWriter("loginDetails.txt",append);
             BufferedWriter bin = new BufferedWriter(theWriter);

            bin.write("¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬¬" + "\n" );
            bin.write(UserID+ "\n");
            bin.write(firstName+ "\n" );
            bin.write(surName+ "\n" );
            bin.write(password+"\n");
            bin.write(designation +"\n");
            bin.write(contactNo+"\n");
            bin.write(Email +"\n");
            bin.write(DOB + "\n");
            
            bin.close();
            bin = null;
                 
            isRegistered = true;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }

        return isRegistered;
    }
    
   
    public boolean verifyUser(String checkUserId, String checkPassword)throws IOException{
        
            boolean isRegistered = false;
            File file = new File("loginDetails.txt");
            
             BufferedReader bufReader = new BufferedReader(new FileReader(file));
            int length = this.CountLines()/9;
            for(int i = 0; i< length; i++){
                bufReader.readLine();
                String storedUserID = bufReader.readLine();
                System.out.print(storedUserID+ "\n");
                bufReader.readLine();
                bufReader.readLine();
                String storedPassword = bufReader.readLine();
                System.out.print(storedPassword);
                bufReader.readLine();
                bufReader.readLine();
                bufReader.readLine();
                bufReader.readLine();
                
                
                if(checkUserId.equals(storedUserID) && checkPassword.equals(storedPassword)){
                    isRegistered = true;
                    break;
                    
                }
                else if(i == length) {
                    isRegistered = false;
                    break;
                }
                
                
                
            }
        return isRegistered;
    }
    
    
    public boolean checkDesignation(String checkFullName, String checkPassword, String chkDesignation) throws IOException{
        boolean flag = false;
        File file = new File("loginDetails.txt");
            
             BufferedReader bufReader = new BufferedReader(new FileReader(file));
            int length = this.CountLines()/9;
            for(int i = 0 ; i< length ; i++){
                  bufReader.readLine();
                  String forFullName = bufReader.readLine();
                  bufReader.readLine();
                  bufReader.readLine();
                  String forPassword = bufReader.readLine();
                  String forRole = bufReader.readLine();
                  bufReader.readLine();
                  bufReader.readLine();
                  bufReader.readLine();
             
                
                if(checkFullName.equals(forFullName) && checkPassword.equals(forPassword) && chkDesignation.equals(forRole)){
                    flag = true;
                    break;
                    
                    
                }
                else if(i==(length)){
                    flag = false;
                    
                }
                  
            }
        return flag;
    }
    
    public String[] getDetails(){
        String [] answers = new String[4];
        
            answers[0] = this.firstName+this.surName;
            answers[1]= this.Email;
            answers[2]= this.contactNo;
            answers[3]= this.designation;
            
            return answers;
    }
    
    
    public User getUser(String userID) throws FileNotFoundException, IOException{
        User auxi = new User();
         boolean isRegistered = false;
             File file = new File("loginDetails.txt");
            
             BufferedReader bufReader = new BufferedReader(new FileReader(file));
            int length = this.CountLines()/9;
            for(int i = 0; i< length; i++){
                String delimitor = bufReader.readLine();
                String storedUserID = bufReader.readLine();
                
                String firstName = bufReader.readLine();
                String surName = bufReader.readLine();
                String storedPassword = bufReader.readLine();
                
                String designation = bufReader.readLine();
                String contactNo = bufReader.readLine();
                String email = bufReader.readLine();
                String DOB = bufReader.readLine();
                
                auxi.Edit(storedUserID,firstName,surName,designation,email,contactNo,storedPassword,LocalDate.parse(DOB));
                
                if(auxi.getUserId().equals(userID)){
                    return auxi;
                }
                else{
                    return new User();
                }
                
            }
        return auxi;    
    }
    
    
    public static void main (String [] args){
        

    }
    
}
