/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package hypermart;

import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


/**
 *
 * @author kanishk-pc
 */
public class product extends javax.swing.JFrame {
    
    private int id;
    private String name;
    private double weight;
    private double price;
    private double VAT;
    private String manufacturerName;
    private LocalDate ExpiryDate;
    private LocalDate lastOrderDate;
    private int reorderQuantity;
    private String picture;
    private int availableQuantity;
    
//    productsList theList = new productsList(); // Real Occurance and Meaning of Stack Overflow Error
    
    
    public String getManufacturerName() {
        return manufacturerName;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    public double getPrice() {
        return price;
    }

    public double getVAT() {
        return VAT;
    }

    public LocalDate getExpiryDate() {
        return ExpiryDate;
    }

    public LocalDate getLastOrderDate() {
        return lastOrderDate;
    }

    public int getReorderQuantity() {
        return reorderQuantity;
    }

    public String getPicture() {
        return picture;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }
    
    public int getID(){
        return id;
    }
    
 
    
    public product() {
        
        id = -1;
        name = "error";
        weight = -1;
        price = -1;
        VAT = -1;
        manufacturerName = null;
        ExpiryDate = LocalDate.of(1900, 12, 15);
        lastOrderDate = LocalDate.of(1800, 12, 20);
        reorderQuantity = -1;
        picture = "error.png";
        availableQuantity = -1;
        
//        theList.loadFromFile();
       
        
    }
    
    private void edit(int id, String name, double weight, double price, double VAT,String manufacturerName, LocalDate Expiry, LocalDate lastOrderDate, int reorderQty, String picture, int availableQty){
      this.id = id;
      this.name = name;
      this.weight = weight;
      this.price = price;
      this.VAT = VAT;
      this.manufacturerName = manufacturerName;
      this.ExpiryDate = Expiry;
      this.lastOrderDate = lastOrderDate;
      this.reorderQuantity = reorderQty;
      this.picture = picture;
      this.availableQuantity = availableQty;
    }
    
    
    
    
    public product(int id, String name, double weight, double price, double VAT,String manufacturerName, LocalDate Expiry, LocalDate lastOrderDate, int reorderQty, String picture, int availableQty){
        this.edit(id, name, weight, price,VAT,manufacturerName, Expiry,lastOrderDate, reorderQty, picture,availableQty);
    }
    
    public String toString(){
        return id+ "\n" + name + "\n" + weight + "\n" + price + "\n" + VAT + "\n" + manufacturerName+ "\n" + ExpiryDate + "\n" + lastOrderDate + "\n"+ reorderQuantity + "\n"+ picture + "\n"+ availableQuantity;
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jExpiry = new javax.swing.JLabel();
        jLastOrder = new javax.swing.JLabel();
        jAvailableQty = new javax.swing.JLabel();
        jminReorderQty = new javax.swing.JLabel();
        productId = new javax.swing.JLabel();
        jname = new javax.swing.JLabel();
        jweight = new javax.swing.JLabel();
        jprice = new javax.swing.JLabel();
        jVat = new javax.swing.JLabel();
        jManuName = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jSmallWarningLabel = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jWarningMessageLabel = new javax.swing.JLabel();
        jReorderLinkButton = new javax.swing.JButton();
        jPicture = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Product Viewer\n");
        setBackground(new java.awt.Color(255, 255, 102));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setForeground(new java.awt.Color(255, 255, 102));

        jPanel1.setBackground(new java.awt.Color(255, 255, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setForeground(new java.awt.Color(255, 255, 102));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jExpiry.setText("null");

        jLastOrder.setText("null");

        jAvailableQty.setText("0");

        jminReorderQty.setText("-1");

        productId.setText("-1");

        jname.setText("null");

        jweight.setText("0");

        jprice.setText("0");

        jVat.setText("12.5");

        jManuName.setText("null");

        jLabel1.setText("Product ID : -");

        jLabel2.setText("Name : -");

        jLabel3.setText("Weight : - ");

        jLabel4.setText("Price : - ");

        jLabel5.setText("VAT : - ");

        jLabel6.setText("Manu. Name : - ");

        jLabel7.setText("Expiry Date : - ");

        jLabel8.setText("Last Order Date : - ");

        jLabel9.setText("Available Qty : - ");

        jLabel10.setText("Min Reorder Qty : - ");

        jSmallWarningLabel.setText("Warning !!!");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLastOrder, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jExpiry, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jManuName, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jVat, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jprice, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jweight, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jname, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(productId, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jminReorderQty, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jAvailableQty, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(jSmallWarningLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(productId)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jname)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jweight)
                    .addComponent(jLabel3))
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jprice)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jVat)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jManuName)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jExpiry)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLastOrder)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAvailableQty)
                    .addComponent(jLabel9)
                    .addComponent(jSmallWarningLabel))
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jminReorderQty)
                    .addComponent(jLabel10))
                .addGap(14, 14, 14))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 0));
        jPanel3.setForeground(new java.awt.Color(255, 255, 0));

        jWarningMessageLabel.setText("Warning ! The Available stock is below the Minimum ReOrder Qty , please");

        jReorderLinkButton.setText("Reorder");
        jReorderLinkButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jReorderLinkButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jWarningMessageLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jReorderLinkButton)
                .addContainerGap(88, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jWarningMessageLabel)
                    .addComponent(jReorderLinkButton))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        jPicture.setBackground(new java.awt.Color(255, 255, 0));
        jPicture.setForeground(new java.awt.Color(255, 255, 0));
        jPicture.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPicture.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPicture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jPicture, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jReorderLinkButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jReorderLinkButtonActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jReorderLinkButtonActionPerformed

   
    public ImageIcon getImageIcon(String title){
        ImageIcon chickenIcon = new ImageIcon("C:\\Users\\44789\\Documents\\NetBeansProjects\\HyperMart\\res\\"+title);
        Image Icon = chickenIcon.getImage();
        Image Icon2 = Icon.getScaledInstance(5,5,java.awt.Image.SCALE_SMOOTH);
        chickenIcon = new ImageIcon(Icon2);
        return chickenIcon;    
    }
    
    public void setFrame(){
        initComponents();
        ImageIcon chickenIcon = new ImageIcon("C:\\Users\\44789\\Documents\\NetBeansProjects\\HyperMart\\res\\"+picture);
        System.out.print("C:\\Users\\44789\\Documents\\NetBeansProjects\\HyperMart\\res\\"+picture);
        Image chicken = chickenIcon.getImage();
        Image chicken2 = chicken.getScaledInstance(300, jPicture.getHeight() - 40, java.awt.Image.SCALE_SMOOTH);
        chickenIcon = new ImageIcon(chicken2);
        jPicture.setIcon(chickenIcon);
        productId.setText(String.valueOf(id));
        jname.setText(String.valueOf(name));
        jweight.setText(String.valueOf(weight));
        jprice.setText(String.valueOf(price));
        jVat.setText(String.valueOf(VAT));
        jManuName.setText(manufacturerName);
        jExpiry.setText(String.valueOf(ExpiryDate));
        jLastOrder.setText(String.valueOf(lastOrderDate));
        jAvailableQty.setText(String.valueOf(availableQuantity));
        jminReorderQty.setText(String.valueOf(reorderQuantity));
        
        if(availableQuantity <= reorderQuantity){
            jWarningMessageLabel.setText("Warning ! The Available stock is below the Minimum ReOrder Qty , please");
            jWarningMessageLabel.setForeground(Color.red);
            jReorderLinkButton.setVisible(true);
            jSmallWarningLabel.setText("Warning !!!");
            jSmallWarningLabel.setForeground(Color.red);
        }
        else {
            jWarningMessageLabel.setText("The Stock Levels are Optimum, No Reorder Required");
            jWarningMessageLabel.setForeground(Color.green);
            jReorderLinkButton.setVisible(false);
            jSmallWarningLabel.setText("");
        }
         
        
        
        
   
       
       this.setVisible(true);
    }
  
    public void loadFromFile(BufferedReader bin){
          
        try {
            
           String Delimitor = bin.readLine();
           int id = Integer.parseInt(bin.readLine());
           String name  = bin.readLine();
           double weight = Double.parseDouble(bin.readLine());
           double price = Double.parseDouble(bin.readLine());
           double VAT = Double.parseDouble(bin.readLine());
           String manuName  = bin.readLine();
           LocalDate Expiry = LocalDate.parse(bin.readLine());
           LocalDate lastOrderDate = LocalDate.parse(bin.readLine());
           int reorderQty = Integer.parseInt(bin.readLine());
           String picture = bin.readLine();
           int availableQty = Integer.parseInt(bin.readLine());
           
           this.edit(id, name, weight, price,VAT,manuName, Expiry, lastOrderDate,reorderQty,picture, availableQty );
           
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void saveToFile(BufferedWriter bin1){
          
       
            
        try {
            bin1.write(id+"\n");
            bin1.write(name+"\n");
            bin1.write(weight+"\n");
            bin1.write(price+"\n");
            bin1.write(VAT+"\n");
            bin1.write(manufacturerName+"\n");
            bin1.write(ExpiryDate+"\n");
            bin1.write(lastOrderDate+"\n");
            bin1.write(reorderQuantity+"\n");
            bin1.write(picture+"\n");
            bin1.write(availableQuantity+"\n");
            
            
        } catch (IOException ex) {
            Logger.getLogger(product.class.getName()).log(Level.SEVERE, null, ex);
        }
           
           
        
    }
    
    
    
    

   
    
    
    
    
    
    
    
    public static void main(String args[]) {
       product p1 = new product();
       p1.setFrame();
        
        
        
       
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jAvailableQty;
    private javax.swing.JLabel jExpiry;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLastOrder;
    private javax.swing.JLabel jManuName;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel jPicture;
    private javax.swing.JButton jReorderLinkButton;
    private javax.swing.JLabel jSmallWarningLabel;
    private javax.swing.JLabel jVat;
    private javax.swing.JLabel jWarningMessageLabel;
    private javax.swing.JLabel jminReorderQty;
    private javax.swing.JLabel jname;
    private javax.swing.JLabel jprice;
    private javax.swing.JLabel jweight;
    private javax.swing.JLabel productId;
    // End of variables declaration//GEN-END:variables
}
